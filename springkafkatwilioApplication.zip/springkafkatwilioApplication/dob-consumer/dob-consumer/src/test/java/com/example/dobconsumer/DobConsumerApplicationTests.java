package com.example.dobconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DobConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
